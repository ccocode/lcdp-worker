/* 星桥杂志主题脚本（AI 生成 · M14.1）：全部数据经平台公开数据面获取
   （见主题开发手册 §7）。上下文只取自 window.__LCDP__，不写死应用 id
   与接口域名；普通字段一律转义、富文本 content 按 HTML 渲染（手册 §8）。 */
(function () {
  "use strict";
  var ctx = window.__LCDP__ || {};
  var cfg = ctx.config || {};
  var apiBase = ctx.apiBase || "";
  var appId = ctx.appId || "";
  var app = document.getElementById("app");

  function pick(v, d) { return v === undefined || v === null || v === "" ? d : v; }
  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function siteName() { return pick(cfg.siteName, "星桥科技"); }
  function fmtDate(s) {
    if (!s) return "";
    return String(s).slice(0, 16).replace("T", " ");
  }
  function fmtDay(s) {
    if (!s) return "";
    return String(s).slice(0, 10);
  }
  function fmtPrice(v) {
    var n = Number(v);
    if (v === null || v === undefined || v === "" || isNaN(n)) return esc(v || "");
    return n.toLocaleString("en-US");
  }
  function coverUrl(row) {
    var c = row && row.cover;
    if (!c) return "";
    var id = "";
    if (Array.isArray(c)) id = c[0] || "";
    else if (typeof c === "string") {
      var t = c.trim();
      if (t.charAt(0) === "[") {
        try { var arr = JSON.parse(t); id = (arr && arr[0]) || ""; } catch (e) { id = ""; }
      } else id = t;
    }
    if (!id) return "";
    if (/^https?:\/\//.test(id)) return id;
    return apiBase + "/assets/" + encodeURIComponent(id) + "/content";
  }
  function get(path) {
    return fetch(apiBase + path).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }
  function rowsOf(j) { return (j && (j.rows || j.items)) || []; }

  /* ---- 站点框架：报头、页脚、主色、日期 ---- */
  document.title = siteName() + " · 星桥杂志";
  var bn = document.getElementById("brand-name"); if (bn) bn.textContent = siteName();
  var mt = document.getElementById("mast-tag"); if (mt) mt.textContent = pick(cfg.tagline, "");
  var fn = document.getElementById("footer-name"); if (fn) fn.textContent = siteName();
  var ft = document.getElementById("footer-tag"); if (ft) ft.textContent = pick(cfg.tagline, "");
  var fc = document.getElementById("footer-copy"); if (fc) fc.textContent = pick(cfg.footerText, "");
  if (cfg.themeColor) document.documentElement.style.setProperty("--brand", cfg.themeColor);
  var td = document.getElementById("today-date");
  if (td) {
    var now = new Date();
    var wd = ["日", "一", "二", "三", "四", "五", "六"][now.getDay()];
    td.textContent = now.getFullYear() + "年" + (now.getMonth() + 1) + "月" + now.getDate() + "日 星期" + wd;
  }

  /* ---- 元数据：栏目与作者（全站共用，拉一次缓存） ---- */
  var metaPromise = null;
  function loadMeta() {
    if (metaPromise) return metaPromise;
    metaPromise = Promise.all([
      get("/public/apps/" + appId + "/data/category?limit=100").then(rowsOf).catch(function () { return []; }),
      get("/public/apps/" + appId + "/data/author?limit=100").then(rowsOf).catch(function () { return []; })
    ]).then(function (res) {
      var cats = res[0].slice().sort(function (a, b) { return (Number(a.sort) || 0) - (Number(b.sort) || 0); });
      var catName = {}, authorName = {};
      cats.forEach(function (c) { catName[c.id] = c.name; });
      res[1].forEach(function (a) { authorName[a.id] = a.name; });
      return { cats: cats, catName: catName, authorName: authorName };
    });
    return metaPromise;
  }
  /* 栏目链接直接作为导航 flex 子项插入（手册 §9：不经无布局的占位容器） */
  function buildNav(meta) {
    var nav = document.getElementById("site-nav");
    var anchor = document.getElementById("nav-products");
    if (!nav || !anchor) return;
    meta.cats.forEach(function (c) {
      var a = document.createElement("a");
      a.href = "/news?cat=" + encodeURIComponent(c.id);
      a.textContent = c.name;
      nav.insertBefore(a, anchor);
    });
  }

  /* ---- 通用渲染片段 ---- */
  function byline(a, meta) {
    var cat = meta.catName[a.category_id] || "";
    var author = meta.authorName[a.author_id] || "";
    var date = fmtDate(a.published_at || a.created_at);
    var parts = [];
    if (cat) parts.push('<span class="cat">' + esc(cat) + "</span>");
    if (author) parts.push("<span>文 / " + esc(author) + "</span>");
    if (date) parts.push("<span>" + esc(date) + "</span>");
    return parts.length ? '<div class="byline">' + parts.join("") + "</div>" : "";
  }
  function featureArticle(a, meta) {
    var cover = coverUrl(a);
    var fig = cover
      ? '<figure><img src="' + esc(cover) + '" alt=""></figure>'
      : "";
    return '<div class="feature">' + fig + "<div>" +
      '<p class="kicker">头条</p>' +
      '<h3><a href="/article?id=' + encodeURIComponent(a.id) + '">' + esc(a.title) + "</a></h3>" +
      byline(a, meta) +
      '<p class="sum">' + esc(a.summary || "") + "</p>" +
      '<a class="read-more" href="/article?id=' + encodeURIComponent(a.id) + '">阅读全文</a>' +
      "</div></div>";
  }
  function storyRow(a, meta) {
    var cat = meta.catName[a.category_id] || "";
    return '<article class="story-row"><div class="story-date">' + esc(fmtDay(a.published_at || a.created_at)) + "</div>" +
      '<div class="story-main"><h3>' +
      (cat ? '<span class="cat">' + esc(cat) + "</span>" : "") +
      '<a href="/article?id=' + encodeURIComponent(a.id) + '">' + esc(a.title) + "</a></h3>" +
      "<p>" + esc(a.summary || "") + "</p></div></article>";
  }
  function productCard(p) {
    var cover = coverUrl(p);
    var media = cover
      ? '<img src="' + esc(cover) + '" alt="" loading="lazy">'
      : '<div class="cover-fallback">' + esc(String(p.name || "星").charAt(0)) + "</div>";
    return '<article class="p-card">' + media +
      "<h3>" + esc(p.name) + "</h3>" +
      '<p class="intro">' + esc(p.intro || "") + "</p>" +
      '<div class="p-price"><span class="price"><small>¥</small>' + fmtPrice(p.price) + "</span>" +
      '<span class="on-sale">在售</span></div></article>';
  }
  function pageHead(title, sub) {
    return '<section class="page-head"><div class="wrap"><h1>' + esc(title) + "</h1>" +
      (sub ? "<p>" + esc(sub) + "</p>" : "") + '<div class="page-rule"></div></div></section>';
  }
  function loading() { app.innerHTML = '<div class="wrap"><p class="loading">正在加载…</p></div>'; }
  function loadError() {
    app.innerHTML = '<div class="wrap"><div class="empty">内容加载失败，请稍后刷新重试。</div></div>';
  }

  /* ---- 页面 ---- */
  function renderHome(meta) {
    document.title = siteName() + " · 星桥杂志";
    var lead =
      '<section class="lead"><div>' +
      '<p class="kicker">本期导读</p>' +
      "<h1>" + esc(pick(cfg.heroTitle, "")) + "</h1>" +
      '<p class="lead-sub">' + esc(pick(cfg.heroSubtitle, "")) + "</p>" +
      '<p class="lead-links"><a href="/news">查看最新动态</a><a href="/contact">联系我们</a></p></div>' +
      '<figure><img src="/assets/hero.webp" alt="星桥科技主视觉"><figcaption>星桥双塔 · 光弧相连</figcaption></figure></section>';
    app.innerHTML = '<div class="wrap">' + lead + '<p class="loading">正在加载…</p></div>';
    Promise.all([
      get("/public/apps/" + appId + "/data/article?limit=6").then(rowsOf).catch(function () { return []; }),
      get("/public/apps/" + appId + "/data/product?limit=20").then(rowsOf).catch(function () { return []; })
    ]).then(function (res) {
      var arts = res[0];
      var prods = res[1].filter(function (p) { return !p.status || p.status === "在售"; }).slice(0, 3);
      var html = '<div class="wrap">' + lead;
      if (arts.length) {
        html += '<section class="section"><div class="section-head"><h2>头条</h2><a class="more" href="/news">全部新闻 →</a></div>' +
          featureArticle(arts[0], meta) + "</section>";
        if (arts.length > 1) {
          html += '<section class="section"><div class="section-head"><h2>最新动态</h2><a class="more" href="/news">全部新闻 →</a></div>' +
            arts.slice(1).map(function (a) { return storyRow(a, meta); }).join("") + "</section>";
        }
      } else {
        html += '<div class="empty">暂无内容</div>';
      }
      if (prods.length) {
        html += '<section class="section"><div class="section-head"><h2>选物</h2><a class="more" href="/products">全部产品 →</a></div>' +
          '<div class="p-grid">' + prods.map(productCard).join("") + "</div></section>";
      }
      var about = pick(cfg.aboutText, "");
      if (about) {
        html += '<section class="section"><div class="section-head"><h2>关于</h2><a class="more" href="/about">了解更多 →</a></div>' +
          '<div class="about-strip"><div class="a-label">关于我们</div><p>' +
          esc(about.length > 220 ? about.slice(0, 220) + "…" : about) + "</p></div></section>";
      }
      html += "</div>";
      app.innerHTML = html;
    }).catch(loadError);
  }

  function renderNews(meta) {
    var q = new URLSearchParams(location.search);
    var cat = q.get("cat") || "";
    var title = cat ? (meta.catName[cat] || "新闻") : "新闻动态";
    document.title = title + " · " + siteName();
    var links = '<div class="wrap"><div class="cat-links"><a href="/news"' + (cat ? "" : ' class="on"') + ">全部</a>" +
      meta.cats.map(function (c) {
        return '<a href="/news?cat=' + encodeURIComponent(c.id) + '"' + (cat === c.id ? ' class="on"' : "") + ">" + esc(c.name) + "</a>";
      }).join("") + "</div></div>";
    app.innerHTML = pageHead(title, "公司新闻、产品动态与行业洞察") + links + '<div class="wrap"><p class="loading">正在加载…</p></div>';
    var url = "/public/apps/" + appId + "/data/article?limit=50" + (cat ? "&category_id=" + encodeURIComponent(cat) : "");
    get(url).then(rowsOf).then(function (arts) {
      app.innerHTML = pageHead(title, "公司新闻、产品动态与行业洞察") + links +
        '<div class="wrap">' +
        (arts.length
          ? arts.map(function (a) { return storyRow(a, meta); }).join("")
          : '<div class="empty">该栏目暂无内容</div>') +
        "</div>";
    }).catch(loadError);
  }

  function renderArticle(meta) {
    var q = new URLSearchParams(location.search);
    var id = q.get("id") || "";
    loading();
    if (!id) { loadError(); return; }
    get("/public/apps/" + appId + "/data/article/" + encodeURIComponent(id)).then(function (row) {
      var a = row && (row.row || row);
      if (!a || !a.id) throw new Error("not found");
      document.title = a.title + " · " + siteName();
      var cover = coverUrl(a);
      var cat = meta.catName[a.category_id] || "";
      app.innerHTML =
        '<div class="wrap"><article class="article">' +
        (cat ? '<p class="kicker">' + esc(cat) + "</p>" : "") +
        "<h1>" + esc(a.title) + "</h1>" +
        byline(a, meta) +
        (cover ? '<figure><img src="' + esc(cover) + '" alt=""></figure>' : "") +
        '<div class="article-body">' + (a.content || "") + "</div></article>" +
        '<a class="backlink" href="/news">← 返回新闻列表</a></div>';
    }).catch(function () {
      document.title = "内容不存在 · " + siteName();
      app.innerHTML = '<div class="wrap"><div class="empty">这篇内容不存在或尚未发布。<br><a href="/news">返回新闻列表</a></div></div>';
    });
  }

  function renderProducts() {
    document.title = "产品 · " + siteName();
    app.innerHTML = pageHead("产品", "星桥自研产品线") + '<div class="wrap"><p class="loading">正在加载…</p></div>';
    get("/public/apps/" + appId + "/data/product?limit=50").then(rowsOf).then(function (prods) {
      var onSale = prods.filter(function (p) { return !p.status || p.status === "在售"; });
      app.innerHTML = pageHead("产品", "星桥自研产品线") +
        '<div class="wrap">' +
        (onSale.length ? '<div class="p-grid">' + onSale.map(productCard).join("") + "</div>" : '<div class="empty">暂无在售产品</div>') +
        "</div>";
    }).catch(loadError);
  }

  function renderAbout() {
    document.title = "关于我们 · " + siteName();
    var about = pick(cfg.aboutText, "");
    var paras = about.split(/\n+/).filter(Boolean).map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("");
    app.innerHTML = pageHead("关于我们", pick(cfg.tagline, "")) +
      '<div class="wrap"><div class="prose">' + (paras || "<p>暂无介绍。</p>") + "</div></div>";
  }

  function renderContact() {
    document.title = "联系我们 · " + siteName();
    app.innerHTML = pageHead("联系我们", "有任何问题或合作意向，欢迎留言，我们会尽快回复") +
      '<div class="wrap"><form class="form-card" id="msg-form">' +
      '<label for="f-name">姓名 *</label><input id="f-name" name="name" required maxlength="50" autocomplete="name">' +
      '<label for="f-contact">联系方式（手机号 / 邮箱）*</label><input id="f-contact" name="contact" required maxlength="80" autocomplete="email">' +
      '<label for="f-content">留言内容 *</label><textarea id="f-content" name="content" rows="5" required maxlength="1000"></textarea>' +
      '<button class="btn-ink" type="submit" id="msg-btn">提交留言</button>' +
      '<p class="form-note">提交后留言将进入审核队列，通过后由工作人员跟进回复。</p>' +
      '<div class="form-err" id="msg-err"></div></form></div>';
    var form = document.getElementById("msg-form");
    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var btn = document.getElementById("msg-btn");
      var err = document.getElementById("msg-err");
      var payload = {
        name: document.getElementById("f-name").value.trim(),
        contact: document.getElementById("f-contact").value.trim(),
        content: document.getElementById("f-content").value.trim()
      };
      if (!payload.name || !payload.contact || !payload.content) {
        err.style.display = "block"; err.textContent = "请把姓名、联系方式与留言内容填写完整。"; return;
      }
      btn.disabled = true; btn.textContent = "提交中…"; err.style.display = "none";
      fetch(apiBase + "/public/apps/" + appId + "/submit/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: payload })
      }).then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) throw new Error(j.message || "提交失败（HTTP " + r.status + "）");
          app.innerHTML = pageHead("联系我们", "") +
            '<div class="wrap"><div class="form-ok">留言已提交，感谢您的反馈！我们的工作人员会尽快与您联系。<br><a href="/">返回首页</a></div></div>';
        });
      }).catch(function (e) {
        btn.disabled = false; btn.textContent = "提交留言";
        err.style.display = "block"; err.textContent = "提交未成功：" + e.message + "。请稍后再试。";
      });
    });
  }

  /* ---- 启动与路由 ---- */
  if (!apiBase || !appId) {
    app.innerHTML = '<div class="wrap"><div class="empty">主题上下文缺失（window.__LCDP__ 未注入），无法加载数据。</div></div>';
    return;
  }
  var path = location.pathname.replace(/\/+$/, "") || "/";
  loadMeta().then(function (meta) {
    buildNav(meta);
    if (path === "/") renderHome(meta);
    else if (path === "/news") renderNews(meta);
    else if (path === "/article") renderArticle(meta);
    else if (path === "/products") renderProducts();
    else if (path === "/about") renderAbout();
    else if (path === "/contact") renderContact();
    else {
      document.title = "页面不存在 · " + siteName();
      app.innerHTML = '<div class="wrap"><div class="empty">页面不存在。<br><a href="/">返回首页</a></div></div>';
    }
  }).catch(loadError);
})();
