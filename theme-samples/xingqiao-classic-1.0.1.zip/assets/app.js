/* 星桥经典主题脚本：全部数据经平台公开数据面获取（见主题开发手册 §7）。
   上下文只取自 window.__LCDP__，不写死应用 id 与接口域名。 */
(function () {
  "use strict";
  var ctx = window.__LCDP__ || {};
  var cfg = ctx.config || {};
  var apiBase = ctx.apiBase || "";
  var appId = ctx.appId || "";
  var app = document.getElementById("app");

  function pick(v, d) { return v === undefined || v === null || v === "" ? d : v; }
  function esc(s) {
    return String(s ?? "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function siteName() { return pick(cfg.siteName, "星桥科技"); }
  function fmtDate(s) {
    if (!s) return "";
    return String(s).slice(0, 16).replace("T", " ");
  }
  function coverUrl(row) {
    var c = row && row.cover;
    if (!c) return "";
    var id = "";
    if (Array.isArray(c)) id = c[0] || "";
    else if (typeof c === "string") {
      var t = c.trim();
      if (t.charAt(0) === "[") {
        try { var arr = JSON.parse(t); id = (arr && arr[0]) || ""; } catch (e) { id = ""; }
      } else id = t;
    }
    if (!id) return "";
    if (/^https?:\/\//.test(id)) return id;
    return apiBase + "/assets/" + encodeURIComponent(id) + "/content";
  }
  function get(path) {
    return fetch(apiBase + path).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }
  function rowsOf(j) { return (j && (j.rows || j.items)) || []; }

  /* ---- 站点框架：品牌、页脚、主色 ---- */
  document.title = siteName();
  var bn = document.getElementById("brand-name"); if (bn) bn.textContent = siteName();
  var fn = document.getElementById("footer-name"); if (fn) fn.textContent = siteName();
  var ft = document.getElementById("footer-tag"); if (ft) ft.textContent = pick(cfg.tagline, "");
  var fc = document.getElementById("footer-copy"); if (fc) fc.textContent = pick(cfg.footerText, "");
  if (cfg.themeColor) document.documentElement.style.setProperty("--brand", cfg.themeColor);
  var toggle = document.getElementById("nav-toggle");
  var nav = document.getElementById("site-nav");
  if (toggle && nav) toggle.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
  });

  /* ---- 元数据：栏目与作者（全站共用，拉一次缓存） ---- */
  var metaPromise = null;
  function loadMeta() {
    if (metaPromise) return metaPromise;
    metaPromise = Promise.all([
      get("/public/apps/" + appId + "/data/category?limit=100").then(rowsOf).catch(function () { return []; }),
      get("/public/apps/" + appId + "/data/author?limit=100").then(rowsOf).catch(function () { return []; })
    ]).then(function (res) {
      var cats = res[0].slice().sort(function (a, b) { return (Number(a.sort) || 0) - (Number(b.sort) || 0); });
      var catName = {}, authorName = {};
      cats.forEach(function (c) { catName[c.id] = c.name; });
      res[1].forEach(function (a) { authorName[a.id] = a.name; });
      return { cats: cats, catName: catName, authorName: authorName };
    });
    return metaPromise;
  }
  function buildNav(meta) {
    var holder = document.getElementById("nav-cats");
    if (!holder) return;
    holder.innerHTML = meta.cats.map(function (c) {
      return '<a href="/news?cat=' + encodeURIComponent(c.id) + '">' + esc(c.name) + "</a>";
    }).join("");
  }

  /* ---- 通用渲染片段 ---- */
  function articleCard(a, meta) {
    var cover = coverUrl(a);
    var img = cover ? '<img class="cover" src="' + esc(cover) + '" alt="" loading="lazy">' : "";
    var cat = meta.catName[a.category_id] || "";
    var date = fmtDate(a.published_at || a.created_at);
    return '<article class="card">' + img + '<div class="card-body">' +
      '<div class="card-meta">' + (cat ? '<span class="cat">' + esc(cat) + "</span>" : "") +
      (date ? "<span>" + esc(date) + "</span>" : "") + "</div>" +
      '<h3><a href="/article?id=' + encodeURIComponent(a.id) + '">' + esc(a.title) + "</a></h3>" +
      '<p class="sum">' + esc(a.summary || "") + "</p></div></article>";
  }
  function productCard(p) {
    var cover = coverUrl(p);
    var img = cover ? '<img class="cover" src="' + esc(cover) + '" alt="" loading="lazy">' : "";
    return '<article class="card">' + img + '<div class="card-body">' +
      "<h3>" + esc(p.name) + "</h3>" +
      '<p class="sum">' + esc(p.intro || "") + "</p>" +
      '<div class="price"><small>¥</small>' + esc(p.price) + "</div></div></article>";
  }
  function pageHead(title, sub) {
    return '<section class="page-head"><div class="wrap"><h1>' + esc(title) + "</h1>" +
      (sub ? "<p>" + esc(sub) + "</p>" : "") + "</div></section>";
  }
  function loading() { app.innerHTML = '<div class="wrap"><p class="loading">正在加载…</p></div>'; }
  function loadError() {
    app.innerHTML = '<div class="wrap"><div class="empty" style="margin:40px 0 46px">内容加载失败，请稍后刷新重试。</div></div>';
  }

  /* ---- 页面 ---- */
  function renderHome(meta) {
    document.title = siteName();
    var hero =
      '<section class="hero"><div class="wrap hero-inner"><div class="hero-copy">' +
      '<p class="hero-kicker">' + esc(siteName()) + "</p>" +
      "<h1>" + esc(pick(cfg.heroTitle, "")) + "</h1>" +
      '<p class="hero-sub">' + esc(pick(cfg.heroSubtitle, "")) + "</p>" +
      '<p class="hero-actions"><a class="btn btn-amber" href="/news">查看最新动态</a>' +
      '<a class="btn btn-ghost" href="/contact">联系我们</a></p></div>' +
      '<div class="hero-art"><img src="/assets/hero.webp" alt="星桥科技主视觉"></div></div></section>';
    app.innerHTML = hero + '<div class="wrap"><p class="loading">正在加载…</p></div>';
    Promise.all([
      get("/public/apps/" + appId + "/data/article?limit=6").then(rowsOf).catch(function () { return []; }),
      get("/public/apps/" + appId + "/data/product?limit=20").then(rowsOf).catch(function () { return []; })
    ]).then(function (res) {
      var arts = res[0];
      var prods = res[1].filter(function (p) { return !p.status || p.status === "在售"; }).slice(0, 3);
      var html = hero;
      html += '<section class="section"><div class="wrap"><div class="section-head"><h2>最新动态</h2><a href="/news">全部新闻 →</a></div>';
      html += arts.length
        ? '<div class="cards">' + arts.map(function (a) { return articleCard(a, meta); }).join("") + "</div>"
        : '<div class="empty">暂无内容</div>';
      html += "</div></section>";
      if (prods.length) {
        html += '<section class="section"><div class="wrap"><div class="section-head"><h2>产品精选</h2><a href="/products">全部产品 →</a></div><div class="cards">' +
          prods.map(productCard).join("") + "</div></div></section>";
      }
      var about = pick(cfg.aboutText, "");
      if (about) {
        html += '<section class="section"><div class="wrap"><div class="section-head"><h2>关于我们</h2><a href="/about">了解更多 →</a></div>' +
          '<div class="prose" style="margin:0 0 46px"><p>' + esc(about.length > 220 ? about.slice(0, 220) + "…" : about) + "</p></div></div></section>";
      }
      app.innerHTML = html;
    }).catch(loadError);
  }

  function renderNews(meta) {
    var q = new URLSearchParams(location.search);
    var cat = q.get("cat") || "";
    var title = cat ? (meta.catName[cat] || "新闻") : "新闻动态";
    document.title = title + " · " + siteName();
    var pills = '<div class="wrap"><div class="cat-pills"><a href="/news"' + (cat ? "" : ' class="on"') + ">全部</a>" +
      meta.cats.map(function (c) {
        return '<a href="/news?cat=' + encodeURIComponent(c.id) + '"' + (cat === c.id ? ' class="on"' : "") + ">" + esc(c.name) + "</a>";
      }).join("") + "</div></div>";
    app.innerHTML = pageHead(title, "公司新闻、产品动态与行业洞察") + pills + '<div class="wrap"><p class="loading">正在加载…</p></div>';
    var url = "/public/apps/" + appId + "/data/article?limit=50" + (cat ? "&category_id=" + encodeURIComponent(cat) : "");
    get(url).then(rowsOf).then(function (arts) {
      app.innerHTML = pageHead(title, "公司新闻、产品动态与行业洞察") + pills +
        '<section style="padding:18px 0 10px"><div class="wrap">' +
        (arts.length
          ? '<div class="cards">' + arts.map(function (a) { return articleCard(a, meta); }).join("") + "</div>"
          : '<div class="empty">该栏目暂无内容</div>') +
        "</div></section>";
    }).catch(loadError);
  }

  function renderArticle(meta) {
    var q = new URLSearchParams(location.search);
    var id = q.get("id") || "";
    loading();
    if (!id) { loadError(); return; }
    get("/public/apps/" + appId + "/data/article/" + encodeURIComponent(id)).then(function (row) {
      var a = row && (row.row || row);
      if (!a || !a.id) throw new Error("not found");
      document.title = a.title + " · " + siteName();
      var cover = coverUrl(a);
      var cat = meta.catName[a.category_id] || "";
      var author = meta.authorName[a.author_id] || "";
      var date = fmtDate(a.published_at || a.created_at);
      app.innerHTML =
        '<div class="wrap"><article class="article"><h1>' + esc(a.title) + "</h1>" +
        '<div class="meta">' +
        (cat ? "<span>栏目：" + esc(cat) + "</span>" : "") +
        (author ? "<span>作者：" + esc(author) + "</span>" : "") +
        (date ? "<span>发布于 " + esc(date) + "</span>" : "") + "</div>" +
        (cover ? '<img class="cover" src="' + esc(cover) + '" alt="">' : "") +
        '<div class="article-body">' + (a.content || "") + "</div></article>" +
        '<a class="backlink" href="/news">← 返回新闻列表</a></div>';
    }).catch(function () {
      document.title = "内容不存在 · " + siteName();
      app.innerHTML = '<div class="wrap"><div class="empty" style="margin:40px 0 46px">这篇内容不存在或尚未发布。<br><a href="/news">返回新闻列表</a></div></div>';
    });
  }

  function renderProducts() {
    document.title = "产品 · " + siteName();
    app.innerHTML = pageHead("产品", "星桥自研产品线") + '<div class="wrap"><p class="loading">正在加载…</p></div>';
    get("/public/apps/" + appId + "/data/product?limit=50").then(rowsOf).then(function (prods) {
      var onSale = prods.filter(function (p) { return !p.status || p.status === "在售"; });
      app.innerHTML = pageHead("产品", "星桥自研产品线") +
        '<section style="padding:26px 0 10px"><div class="wrap">' +
        (onSale.length ? '<div class="cards">' + onSale.map(productCard).join("") + "</div>" : '<div class="empty">暂无在售产品</div>') +
        "</div></section>";
    }).catch(loadError);
  }

  function renderAbout() {
    document.title = "关于我们 · " + siteName();
    var about = pick(cfg.aboutText, "");
    var paras = about.split(/\n+/).filter(Boolean).map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("");
    app.innerHTML = pageHead("关于我们", pick(cfg.tagline, "")) +
      '<div class="wrap"><div class="prose">' + (paras || "<p>暂无介绍。</p>") + "</div></div>";
  }

  function renderContact() {
    document.title = "联系我们 · " + siteName();
    app.innerHTML = pageHead("联系我们", "有任何问题或合作意向，欢迎留言，我们会尽快回复") +
      '<div class="wrap"><form class="form-card" id="msg-form">' +
      '<label for="f-name">姓名 *</label><input id="f-name" name="name" required maxlength="50" autocomplete="name">' +
      '<label for="f-contact">联系方式（手机号 / 邮箱）*</label><input id="f-contact" name="contact" required maxlength="80" autocomplete="email">' +
      '<label for="f-content">留言内容 *</label><textarea id="f-content" name="content" rows="5" required maxlength="1000"></textarea>' +
      '<div style="margin-top:20px"><button class="btn btn-brand" type="submit" id="msg-btn">提交留言</button></div>' +
      '<p class="form-note">提交后留言将进入审核队列，通过后由工作人员跟进回复。</p>' +
      '<div class="form-err" id="msg-err"></div></form></div>';
    var form = document.getElementById("msg-form");
    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var btn = document.getElementById("msg-btn");
      var err = document.getElementById("msg-err");
      var payload = {
        name: document.getElementById("f-name").value.trim(),
        contact: document.getElementById("f-contact").value.trim(),
        content: document.getElementById("f-content").value.trim()
      };
      if (!payload.name || !payload.contact || !payload.content) {
        err.style.display = "block"; err.textContent = "请把姓名、联系方式与留言内容填写完整。"; return;
      }
      btn.disabled = true; btn.textContent = "提交中…"; err.style.display = "none";
      fetch(apiBase + "/public/apps/" + appId + "/submit/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body: payload })
      }).then(function (r) {
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) throw new Error(j.message || "提交失败（HTTP " + r.status + "）");
          app.innerHTML = pageHead("联系我们", "") +
            '<div class="wrap"><div class="form-ok">✓ 留言已提交，感谢您的反馈！我们的工作人员会尽快与您联系。<br><a href="/">返回首页</a></div></div>';
        });
      }).catch(function (e) {
        btn.disabled = false; btn.textContent = "提交留言";
        err.style.display = "block"; err.textContent = "提交未成功：" + e.message + "。请稍后再试。";
      });
    });
  }

  /* ---- 启动与路由 ---- */
  if (!apiBase || !appId) {
    app.innerHTML = '<div class="wrap"><div class="empty" style="margin:40px 0">主题上下文缺失（window.__LCDP__ 未注入），无法加载数据。</div></div>';
    return;
  }
  var path = location.pathname.replace(/\/+$/, "") || "/";
  loadMeta().then(function (meta) {
    buildNav(meta);
    if (path === "/") renderHome(meta);
    else if (path === "/news") renderNews(meta);
    else if (path === "/article") renderArticle(meta);
    else if (path === "/products") renderProducts();
    else if (path === "/about") renderAbout();
    else if (path === "/contact") renderContact();
    else {
      document.title = "页面不存在 · " + siteName();
      app.innerHTML = '<div class="wrap"><div class="empty" style="margin:40px 0 46px">页面不存在。<br><a href="/">返回首页</a></div></div>';
    }
  }).catch(loadError);
})();
